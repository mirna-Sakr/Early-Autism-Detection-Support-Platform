import 'package:flutter/material.dart';
import 'screens/login_screen.dart';
// import 'data/repository_provider.dart';

void main() {
  // When your API is ready, switch the data source here:
  // RepositoryProvider.useApiRepository(baseUrl: 'https://your-api.com');

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Early Autism Detection',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blueGrey,
        useMaterial3: true,
      ),
      home: const LoginScreen(),
    );
  }
}
