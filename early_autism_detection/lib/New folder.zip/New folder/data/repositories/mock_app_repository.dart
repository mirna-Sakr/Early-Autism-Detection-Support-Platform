import '../models/app_notification.dart';
import '../models/behavior_metrics.dart';
import '../models/child_profile.dart';
import '../models/recommendation.dart';
import 'app_repository.dart';

/// In-memory data source used until the API is connected.
/// Replace via [RepositoryProvider.useApiRepository] when ready.
class MockAppRepository implements AppRepository {
  final Map<String, ChildProfile> _profiles = {};
  final Map<String, BehaviorMetrics> _behaviorMetrics = {};
  final Map<String, String> _passwords = {};

  MockAppRepository() {
    _seedDefaultData();
  }

  void _seedDefaultData() {
    const defaultId = 'CHILD001';
    _profiles[defaultId] = ChildProfile(
      name: 'Demo Child',
      personId: defaultId,
      age: 3,
      heightCm: 95,
      bloodType: 'O+',
      imageUrl: null,
      lastAssessment: DateTime.now().subtract(const Duration(days: 2)),
    );
    _passwords[defaultId] = 'demo123';
    _behaviorMetrics[defaultId] = const BehaviorMetrics(
      eyeContactPercentage: 0.65,
      socialInteractionPercentage: 0.45,
      lastUpdated: null,
    );
  }

  static const _allRecommendations = [
    Recommendation(
      id: '1',
      title: 'Occupational Therapy',
      description:
          'Enhances daily living skills, fine motor coordination, and sensory integration for functional independence.',
    ),
    Recommendation(
      id: '2',
      title: 'Speech Therapy',
      description:
          'Improves verbal and nonverbal communication, articulation, and language comprehension.',
    ),
    Recommendation(
      id: '3',
      title: 'Applied Behavior Analysis',
      description:
          'Uses data-driven strategies to reinforce positive behaviors and reduce challenging behaviors.',
    ),
    Recommendation(
      id: '4',
      title: 'Sensory Integration Therapy',
      description:
          'Helps regulate sensory processing and responses to environmental stimuli.',
    ),
    Recommendation(
      id: '5',
      title: 'Social Skills Training',
      description:
          'Develops interpersonal communication, understanding of social cues, and cooperative play.',
    ),
    Recommendation(
      id: '6',
      title: 'Special Education Programs',
      description:
          'Provides structured learning and communication strategies tailored to individual needs.',
    ),
    Recommendation(
      id: '7',
      title: 'Aquatic Therapy',
      description:
          'Supports motor skill development, coordination, and therapeutic movement in a water environment.',
    ),
    Recommendation(
      id: '8',
      title: 'Art & Music Therapy',
      description:
          'Facilitates emotional expression, creativity, and social engagement through creative modalities.',
    ),
  ];

  @override
  Future<ChildProfile> login({
    required String name,
    required String personId,
    required String password,
  }) async {
    await Future.delayed(const Duration(milliseconds: 300));

    final profile = _profiles[personId];
    if (profile == null || _passwords[personId] != password) {
      throw Exception('Invalid credentials');
    }

    return profile.copyWith(name: name);
  }

  @override
  Future<ChildProfile> signUp({
    required String name,
    required String personId,
    required String password,
  }) async {
    await Future.delayed(const Duration(milliseconds: 300));

    if (_profiles.containsKey(personId)) {
      throw Exception('Person ID already exists');
    }

    final profile = ChildProfile(
      name: name,
      personId: personId,
      age: 3,
      heightCm: 95,
      bloodType: 'O+',
      lastAssessment: DateTime.now(),
    );

    _profiles[personId] = profile;
    _passwords[personId] = password;
    _behaviorMetrics[personId] = const BehaviorMetrics(
      eyeContactPercentage: 0.5,
      socialInteractionPercentage: 0.5,
    );

    return profile;
  }

  @override
  Future<ChildProfile> getProfile(String personId) async {
    await Future.delayed(const Duration(milliseconds: 200));

    final profile = _profiles[personId];
    if (profile == null) {
      throw Exception('Profile not found');
    }
    return profile;
  }

  @override
  Future<ChildProfile> updateProfile(
    ChildProfile profile, {
    String? previousPersonId,
  }) async {
    await Future.delayed(const Duration(milliseconds: 200));

    if (previousPersonId != null && previousPersonId != profile.personId) {
      _profiles.remove(previousPersonId);
      final password = _passwords.remove(previousPersonId);
      if (password != null) {
        _passwords[profile.personId] = password;
      }
      final metrics = _behaviorMetrics.remove(previousPersonId);
      if (metrics != null) {
        _behaviorMetrics[profile.personId] = metrics;
      }
    }

    _profiles[profile.personId] = profile;
    return profile;
  }

  @override
  Future<BehaviorMetrics> getBehaviorMetrics(String personId) async {
    await Future.delayed(const Duration(milliseconds: 200));

    return _behaviorMetrics[personId] ??
        const BehaviorMetrics(
          eyeContactPercentage: 0.0,
          socialInteractionPercentage: 0.0,
        );
  }

  @override
  Future<List<Recommendation>> getRecommendations({
    required String personId,
    required double level,
  }) async {
    await Future.delayed(const Duration(milliseconds: 200));

    if (level >= 1 && level <= 2) {
      return _allRecommendations.sublist(0, 3);
    } else if (level > 2 && level <= 3) {
      return _allRecommendations.sublist(0, 6);
    } else if (level > 3) {
      return List.from(_allRecommendations);
    }
    return _allRecommendations.sublist(0, 1);
  }

  @override
  Future<AppNotification> getDailyReminder(String personId) async {
    await Future.delayed(const Duration(milliseconds: 150));

    return const AppNotification(
      id: 'daily_reminder',
      title: 'Daily Reminder!',
      message:
          'Time for daily observation.\nTrack your child\'s behavior for today.',
    );
  }
}
