import '../models/app_notification.dart';
import '../models/behavior_metrics.dart';
import '../models/child_profile.dart';
import '../models/recommendation.dart';
import 'app_repository.dart';

/// API-backed repository — implement each method when your backend is ready.
///
/// Example endpoint mapping (adjust to match your API):
/// - POST /auth/login          → login()
/// - POST /auth/signup         → signUp()
/// - GET  /children/{id}       → getProfile()
/// - PUT  /children/{id}       → updateProfile()
/// - GET  /children/{id}/behavior → getBehaviorMetrics()
/// - GET  /children/{id}/recommendations?level= → getRecommendations()
/// - GET  /children/{id}/notifications/daily → getDailyReminder()
class ApiAppRepository implements AppRepository {
  final String baseUrl;

  ApiAppRepository({required this.baseUrl});

  Never _notImplemented(String method) =>
      throw UnimplementedError('$method is not implemented yet. Connect your API in api_app_repository.dart');

  @override
  Future<ChildProfile> login({
    required String name,
    required String personId,
    required String password,
  }) async {
    _notImplemented('login');
  }

  @override
  Future<ChildProfile> signUp({
    required String name,
    required String personId,
    required String password,
  }) async {
    _notImplemented('signUp');
  }

  @override
  Future<ChildProfile> getProfile(String personId) async {
    _notImplemented('getProfile');
  }

  @override
  Future<ChildProfile> updateProfile(
    ChildProfile profile, {
    String? previousPersonId,
  }) async {
    _notImplemented('updateProfile');
  }

  @override
  Future<BehaviorMetrics> getBehaviorMetrics(String personId) async {
    _notImplemented('getBehaviorMetrics');
  }

  @override
  Future<List<Recommendation>> getRecommendations({
    required String personId,
    required double level,
  }) async {
    _notImplemented('getRecommendations');
  }

  @override
  Future<AppNotification> getDailyReminder(String personId) async {
    _notImplemented('getDailyReminder');
  }
}
