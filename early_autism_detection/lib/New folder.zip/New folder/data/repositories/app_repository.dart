import '../models/app_notification.dart';
import '../models/behavior_metrics.dart';
import '../models/child_profile.dart';
import '../models/recommendation.dart';

/// Single entry point for all app data.
/// Swap [MockAppRepository] for [ApiAppRepository] when the backend is ready.
abstract class AppRepository {
  Future<ChildProfile> login({
    required String name,
    required String personId,
    required String password,
  });

  Future<ChildProfile> signUp({
    required String name,
    required String personId,
    required String password,
  });

  Future<ChildProfile> getProfile(String personId);

  Future<ChildProfile> updateProfile(
    ChildProfile profile, {
    String? previousPersonId,
  });

  Future<BehaviorMetrics> getBehaviorMetrics(String personId);

  Future<List<Recommendation>> getRecommendations({
    required String personId,
    required double level,
  });

  Future<AppNotification> getDailyReminder(String personId);
}
