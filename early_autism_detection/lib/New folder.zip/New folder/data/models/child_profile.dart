class ChildProfile {
  final String name;
  final String personId;
  final int age;
  final double heightCm;
  final String bloodType;
  final String? imageUrl;
  final DateTime? lastAssessment;

  const ChildProfile({
    required this.name,
    required this.personId,
    required this.age,
    required this.heightCm,
    required this.bloodType,
    this.imageUrl,
    this.lastAssessment,
  });

  ChildProfile copyWith({
    String? name,
    String? personId,
    int? age,
    double? heightCm,
    String? bloodType,
    String? imageUrl,
    DateTime? lastAssessment,
  }) {
    return ChildProfile(
      name: name ?? this.name,
      personId: personId ?? this.personId,
      age: age ?? this.age,
      heightCm: heightCm ?? this.heightCm,
      bloodType: bloodType ?? this.bloodType,
      imageUrl: imageUrl ?? this.imageUrl,
      lastAssessment: lastAssessment ?? this.lastAssessment,
    );
  }

  factory ChildProfile.fromJson(Map<String, dynamic> json) {
    return ChildProfile(
      name: json['name'] as String,
      personId: json['person_id'] as String? ?? json['personId'] as String,
      age: json['age'] as int,
      heightCm: (json['height_cm'] ?? json['heightCm'] as num).toDouble(),
      bloodType: json['blood_type'] as String? ?? json['bloodType'] as String,
      imageUrl: json['image_url'] as String? ?? json['imageUrl'] as String?,
      lastAssessment: json['last_assessment'] != null
          ? DateTime.parse(json['last_assessment'] as String)
          : json['lastAssessment'] != null
              ? DateTime.parse(json['lastAssessment'] as String)
              : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'person_id': personId,
      'age': age,
      'height_cm': heightCm,
      'blood_type': bloodType,
      'image_url': imageUrl,
      'last_assessment': lastAssessment?.toIso8601String(),
    };
  }
}
