import 'package:flutter/material.dart';
import '../data/models/child_profile.dart';
import '../widgets/profile_avatar.dart';
import 'track_behaviour_screen.dart';
import 'profile_screen.dart';
import 'recommendations_screen.dart';

class MainScreen extends StatefulWidget {
  final ChildProfile profile;

  const MainScreen({
    super.key,
    required this.profile,
  });

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  late ChildProfile _profile;

  @override
  void initState() {
    super.initState();
    _profile = widget.profile;
  }

  Future<void> _openProfile() async {
    final updated = await Navigator.push<ChildProfile>(
      context,
      MaterialPageRoute(
        builder: (context) => ProfileScreen(personId: _profile.personId),
      ),
    );

    if (updated != null) {
      setState(() => _profile = updated);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Home'),
        backgroundColor: Colors.grey.shade800,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.grey.shade50,
              Colors.white,
            ],
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    ProfileAvatar(
                      imageUrl: _profile.imageUrl,
                      radius: 40,
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Welcome, ${_profile.name}',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Colors.grey.shade800,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 40),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildIconButton(
                    context,
                    icon: Icons.analytics,
                    label: 'Track\nBehavior',
                    color: Colors.grey.shade600,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => TrackBehaviourScreen(
                            personId: _profile.personId,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildIconButton(
                    context,
                    icon: Icons.recommend,
                    label: 'Recommend\nActivities',
                    color: Colors.grey.shade500,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => RecommendationsScreen(
                            personId: _profile.personId,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildIconButton(
                    context,
                    icon: Icons.person,
                    label: 'Child\nProfile',
                    color: Colors.grey.shade700,
                    onTap: _openProfile,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildIconButton(
    BuildContext context, {
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 90,
            height: 90,
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: color.withOpacity(0.2),
                  blurRadius: 10,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: Icon(
              icon,
              size: 45,
              color: color,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}
